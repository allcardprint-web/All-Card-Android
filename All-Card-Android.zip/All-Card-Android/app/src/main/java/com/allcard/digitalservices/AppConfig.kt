package com.allcard.digitalservices

import android.net.Uri

object AppConfig {
    /**
     * Aapki LIVE website (GitHub Pages) ka link. App isi ko kholega, isliye web me jo bhi update karo
     * (naya section, tool, admin change) wo app me bina dobara APK banaye aa jayega.
     * Agar aapka link alag hai to sirf yahi ek line badalni hai.
     */
    const val LIVE_URL = "https://chandramohan2026.github.io/All-Card/"

    /** true = live link kholo (agar na chale to app ke andar rakhi copy). false = hamesha app ke andar wali copy. */
    const val USE_LIVE_URL = true

    /** App ke assets/ folder wali index.html isi (virtual https) address par chalti hai. */
    const val ASSET_HOST = "appassets.androidplatform.net"
    const val LOCAL_URL = "https://appassets.androidplatform.net/index.html"

    val liveHost: String get() = Uri.parse(LIVE_URL).host ?: ""
}
