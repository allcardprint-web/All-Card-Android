package com.allcard.digitalservices

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Web page (JavaScript) se aane wali files ko Android me save / share karta hai.
 * Chrome ke blob: download block hote hain, isliye page file ke tukde (chunks) yahan bhejta hai.
 */
class DownloadBridge(
    private val activity: Activity,
    private val onSaved: (Uri, String, String) -> Unit,
    private val onPrint: () -> Unit
) {
    private class Pending(val file: File, val out: FileOutputStream, val name: String, val mime: String)

    private val pending = ConcurrentHashMap<String, Pending>()
    private val ui = Handler(Looper.getMainLooper())

    private fun safe(id: String?): String = (id ?: "").replace(Regex("[^A-Za-z0-9_-]"), "")

    @JavascriptInterface
    fun begin(id: String?, name: String?, mime: String?) {
        try {
            val dir = File(activity.cacheDir, "dl")
            dir.mkdirs()
            val key = safe(id)
            val f = File(dir, "$key.tmp")
            pending[key] = Pending(f, FileOutputStream(f), name ?: "", mime ?: "")
        } catch (e: Exception) {
            toast("Download shuru nahi hua: " + e.message)
        }
    }

    @JavascriptInterface
    fun chunk(id: String?, b64: String?) {
        val p = pending[safe(id)] ?: return
        try {
            if (!b64.isNullOrEmpty()) p.out.write(Base64.decode(b64, Base64.DEFAULT))
        } catch (e: Exception) {
            toast("Download me error: " + e.message)
        }
    }

    @JavascriptInterface
    fun finishSave(id: String?) {
        val p = pending.remove(safe(id)) ?: return
        try {
            p.out.close()
            val res = FileSaver.saveToDownloads(activity, p.file, p.name, p.mime)
            ui.post { onSaved(res.uri, res.name, res.mime) }
        } catch (e: Exception) {
            toast("Save nahi hua: " + e.message)
        } finally {
            p.file.delete()
        }
    }

    @JavascriptInterface
    fun share(idsJson: String?, title: String?, text: String?, url: String?) {
        val ids = try { JSONArray(idsJson ?: "[]") } catch (e: Exception) { JSONArray() }
        val uris = ArrayList<Uri>()
        var mime = ""
        val shareDir = File(activity.cacheDir, "share")
        shareDir.mkdirs()
        for (i in 0 until ids.length()) {
            val p = pending.remove(safe(ids.optString(i))) ?: continue
            try {
                p.out.close()
                val m = FileSaver.guessMime(p.name, p.mime)
                val name = FileSaver.cleanName(p.name, m)
                val dest = File(shareDir, name)
                p.file.copyTo(dest, overwrite = true)
                uris.add(FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", dest))
                mime = if (mime.isEmpty() || mime == m) m else "*/*"
            } catch (e: Exception) {
                toast("Share file me error: " + e.message)
            } finally {
                p.file.delete()
            }
        }
        val body = listOf(text ?: "", url ?: "").filter { it.isNotBlank() }.joinToString("\n")
        ui.post {
            try {
                val intent = when {
                    uris.size > 1 -> Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                        putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                        type = mime
                    }
                    uris.size == 1 -> Intent(Intent.ACTION_SEND).apply {
                        putExtra(Intent.EXTRA_STREAM, uris[0])
                        type = mime
                    }
                    else -> Intent(Intent.ACTION_SEND).apply { type = "text/plain" }
                }
                if (body.isNotEmpty()) intent.putExtra(Intent.EXTRA_TEXT, body)
                if (!title.isNullOrBlank()) intent.putExtra(Intent.EXTRA_SUBJECT, title)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                activity.startActivity(Intent.createChooser(intent, "Share karein"))
            } catch (e: Exception) {
                Toast.makeText(activity, "Share nahi ho paya", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun print() {
        ui.post { onPrint() }
    }

    @JavascriptInterface
    fun toast(msg: String?) {
        ui.post { Toast.makeText(activity, msg ?: "", Toast.LENGTH_SHORT).show() }
    }

    companion object {
        fun cleanTemp(ctx: Context) {
            try {
                File(ctx.cacheDir, "dl").deleteRecursively()
                File(ctx.cacheDir, "share").deleteRecursively()
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}
