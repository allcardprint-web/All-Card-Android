package com.allcard.digitalservices

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** Admin ka command (Current / Live / Stop) app band hone par bhi yahin aata hai. */
class FcmService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        PushCfg.saveToken(this, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        try {
            val d = message.data
            val type = d["type"] ?: return
            val id = d["id"]?.toLongOrNull() ?: 0L
            val c = Creds.get(this) ?: return   // user ne Sharing ON nahi ki / logout ho gaya
            if (id > 0 && id <= Creds.lastCmd(this)) return
            if (type == "stop") {
                LocationService.stop(this)
                Creds.setLastCmd(this, id)
                return
            }
            val until = d["until"]?.toLongOrNull() ?: 0L
            if (type == "live" && until <= System.currentTimeMillis()) return
            Creds.setLastCmd(this, id)
            LocationService.startCmd(
                this,
                if (type == "current") "current" else "live",
                until,
                c.uid, c.key, c.proj, c.rt
            )
        } catch (e: Exception) {
            // ignore
        }
    }
}
