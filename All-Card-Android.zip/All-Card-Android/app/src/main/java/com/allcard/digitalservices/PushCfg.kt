package com.allcard.digitalservices

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.messaging.FirebaseMessaging

/** Push (FCM) ki settings. Android App ID Admin page se aati hai, isliye google-services.json ki zarurat nahi. */
object PushCfg {
    private const val P = "pushcfg"

    fun save(ctx: Context, appId: String, apiKey: String, project: String, sender: String) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putString("appId", appId).putString("key", apiKey)
            .putString("proj", project).putString("sender", sender).apply()
        ensureInit(ctx)
    }

    fun ensureInit(ctx: Context): Boolean {
        val sp = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        val appId = sp.getString("appId", "") ?: ""
        if (appId.isBlank()) return false
        return try {
            if (FirebaseApp.getApps(ctx).isEmpty()) {
                val o = FirebaseOptions.Builder()
                    .setApplicationId(appId)
                    .setApiKey(sp.getString("key", "") ?: "")
                    .setProjectId(sp.getString("proj", "") ?: "")
                    .setGcmSenderId(sp.getString("sender", "") ?: "")
                    .build()
                FirebaseApp.initializeApp(ctx.applicationContext, o)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun fetchToken(ctx: Context) {
        if (!ensureInit(ctx)) return
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { t ->
                if (t.isSuccessful) saveToken(ctx, t.result ?: "")
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun saveToken(ctx: Context, token: String) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("token", token).apply()
    }

    fun getToken(ctx: Context): String =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).getString("token", "") ?: ""
}

/** User ka login (refresh token) jo background me Firestore likhne ke kaam aata hai. Sharing OFF / logout par mit jata hai. */
object Creds {
    private const val P = "loccreds"

    class C(val uid: String, val key: String, val proj: String, val rt: String)

    fun save(ctx: Context, uid: String, key: String, proj: String, rt: String) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putString("uid", uid).putString("key", key).putString("proj", proj).putString("rt", rt).apply()
    }

    fun get(ctx: Context): C? {
        val sp = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        val uid = sp.getString("uid", "") ?: ""
        val rt = sp.getString("rt", "") ?: ""
        if (uid.isBlank() || rt.isBlank()) return null
        return C(uid, sp.getString("key", "") ?: "", sp.getString("proj", "") ?: "", rt)
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun updateRt(ctx: Context, rt: String) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("rt", rt).apply()
    }

    fun lastCmd(ctx: Context): Long = ctx.getSharedPreferences(P, Context.MODE_PRIVATE).getLong("lastCmd", 0L)

    fun setLastCmd(ctx: Context, id: Long) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putLong("lastCmd", id).apply()
    }
}
