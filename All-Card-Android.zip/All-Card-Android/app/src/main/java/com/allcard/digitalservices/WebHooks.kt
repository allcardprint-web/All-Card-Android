package com.allcard.digitalservices

/**
 * Web page me page-load ke sath chalne wali JavaScript.
 * - a[download] / blob: / data: downloads ko Android bridge se Downloads folder me save karwati hai
 * - navigator.share (file ke sath) ko Android share-sheet se jodti hai (WhatsApp me file/PDF bhejna)
 * - window.print() ko Android print se jodti hai
 * - "Install App" wale option chhupane ke liye ap_installed flag set karti hai
 */
object WebHooks {
    const val SCRIPT = """
(function(){
  var B=window.AndroidBridge;
  if(!B||window.__acHook){return;}
  window.__acHook=true;
  try{localStorage.setItem('ap_installed','1');}catch(e){}
  function toast(m){try{B.toast(String(m));}catch(e){}}
  function fast(){var f=window.AndroidFast;return(f&&typeof f.postMessage==='function')?f:null;}
  function newId(){return 'f'+Date.now()+Math.floor(Math.random()*1000000);}
  function sendSlow(blob,name){
    return new Promise(function(res,rej){
      var id=newId();
      var SZ=3145728,pos=0;
      try{B.begin(id,name||'',blob.type||'');}catch(e){rej(e);return;}
      (function next(){
        if(pos>=blob.size){res({id:id,fast:false});return;}
        var fr=new FileReader();
        fr.onerror=function(){rej(fr.error);};
        fr.onload=function(){
          try{var d=String(fr.result);B.chunk(id,d.substring(d.indexOf(',')+1));}catch(e){rej(e);return;}
          pos+=SZ;next();
        };
        fr.readAsDataURL(blob.slice(pos,pos+SZ));
      })();
    });
  }
  function sendBlob(blob,name){
    var F=fast();
    if(F&&blob.arrayBuffer){
      return blob.arrayBuffer().then(function(buf){
        var id=newId();
        F.postMessage(JSON.stringify({t:'b',id:id,n:name||'',m:blob.type||''}));
        var SZ=8388608;
        for(var p=0;p<buf.byteLength;p+=SZ){F.postMessage(buf.slice(p,Math.min(p+SZ,buf.byteLength)));}
        return {id:id,fast:true};
      });
    }
    return sendSlow(blob,name);
  }
  function finish(r){
    if(r.fast){fast().postMessage(JSON.stringify({t:'s',id:r.id}));}
    else{B.finishSave(r.id);}
  }
  function fail(e){try{B.downloadFailed(String(e));}catch(x){}}
  function saveBlob(blob,name){
    try{B.downloadStarted(name||'');}catch(x){}
    sendBlob(blob,name).then(finish).catch(fail);
  }
  window.__acSaveBlob=saveBlob;
  var URLS={};
  function hook(win){
    try{
      if(win.__acH){return;}
      win.__acH=true;
      var doc=win.document;
      try{
        var oCU=win.URL.createObjectURL,oRU=win.URL.revokeObjectURL;
        win.URL.createObjectURL=function(o){
          var u=oCU.apply(this,arguments);
          try{if(o&&typeof o.size==='number'&&typeof o.slice==='function'){URLS[u]=o;}}catch(e){}
          return u;
        };
        win.URL.revokeObjectURL=function(u){
          try{setTimeout(function(){delete URLS[u];},60000);}catch(e){}
          return oRU.apply(this,arguments);
        };
      }catch(e){}
      function handleAnchor(a){
        try{
          if(!a||a.tagName!=='A'||!a.hasAttribute('download')){return false;}
          var h=a.href||'';
          if(h.indexOf('blob:')!==0&&h.indexOf('data:')!==0){return false;}
          var nm=a.getAttribute('download')||'';
          var kb=URLS[h];
          if(kb){saveBlob(kb,nm);return true;}
          win.fetch(h).then(function(r){return r.blob();}).then(function(b){saveBlob(b,nm);}).catch(fail);
          return true;
        }catch(e){return false;}
      }
      var AP=win.HTMLAnchorElement.prototype,oc=AP.click;
      AP.click=function(){if(handleAnchor(this)){return;}return oc.apply(this,arguments);};
      var ET=win.EventTarget.prototype,od=ET.dispatchEvent;
      ET.dispatchEvent=function(ev){
        try{if(ev&&ev.type==='click'&&this instanceof win.HTMLAnchorElement&&handleAnchor(this)){return true;}}catch(e){}
        return od.apply(this,arguments);
      };
      doc.addEventListener('click',function(ev){
        var n=ev.target;
        while(n&&n.tagName!=='A'){n=n.parentNode;}
        if(n&&handleAnchor(n)){ev.preventDefault();ev.stopPropagation();}
      },true);
      win.print=function(){try{B.print();}catch(e){}};
      var nav=win.navigator;
      Object.defineProperty(nav,'canShare',{configurable:true,writable:true,value:function(d){
        return !!d&&((d.files&&d.files.length>0)||!!d.text||!!d.url||!!d.title);
      }});
      Object.defineProperty(nav,'share',{configurable:true,writable:true,value:function(d){
        d=d||{};
        var files=d.files||[],tasks=[];
        for(var i=0;i<files.length;i++){tasks.push(sendBlob(files[i],files[i].name||('file'+i)));}
        return Promise.all(tasks).then(function(rs){
          var ids=rs.map(function(r){return r.id;});
          var F=fast();
          if(rs.length&&rs[0].fast&&F){F.postMessage(JSON.stringify({t:'h',ids:ids,title:d.title||'',text:d.text||'',url:d.url||''}));}
          else{B.share(JSON.stringify(ids),d.title||'',d.text||'',d.url||'');}
        });
      }});
    }catch(e){}
  }
  hook(window);
  function hookFrames(){
    var f=document.getElementsByTagName('iframe');
    for(var i=0;i<f.length;i++){
      try{if(f[i].contentWindow&&f[i].contentWindow.document){hook(f[i].contentWindow);}}catch(e){}
    }
  }
  document.addEventListener('load',function(ev){
    var t=ev.target;
    if(t&&t.tagName==='IFRAME'){try{hook(t.contentWindow);}catch(e){}}
  },true);
  function overrides(){
    window.apSaveBlob=function(blob,name){saveBlob(blob,name);};
    hookFrames();
  }
  overrides();
  document.addEventListener('DOMContentLoaded',overrides);
  window.addEventListener('load',overrides);
})();
"""
}
