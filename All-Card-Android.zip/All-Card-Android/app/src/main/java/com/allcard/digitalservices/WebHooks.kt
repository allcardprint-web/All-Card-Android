package com.allcard.digitalservices

/**
 * Web page me page-load ke sath chalne wali JavaScript.
 * - a[download] / blob: / data: downloads ko Android bridge se Downloads folder me save karwati hai
 * - navigator.share (file ke sath) ko Android share-sheet se jodti hai (WhatsApp me file/PDF bhejna)
 * - window.print() ko Android print se jodti hai
 * - "Install App" wale option chhupane ke liye ap_installed flag set karti hai
 */
object WebHooks {
    const val SCRIPT = """
(function(){
  var B=window.AndroidBridge;
  if(!B||window.__acHook){return;}
  window.__acHook=true;
  try{localStorage.setItem('ap_installed','1');}catch(e){}
  function toast(m){try{B.toast(String(m));}catch(e){}}
  function sendBlob(blob,name){
    return new Promise(function(res,rej){
      var id='f'+Date.now()+Math.floor(Math.random()*1000000);
      var SZ=589824,pos=0;
      try{B.begin(id,name||'',blob.type||'');}catch(e){rej(e);return;}
      (function next(){
        if(pos>=blob.size){res(id);return;}
        var fr=new FileReader();
        fr.onerror=function(){rej(fr.error);};
        fr.onload=function(){
          try{var d=String(fr.result);B.chunk(id,d.substring(d.indexOf(',')+1));}catch(e){rej(e);return;}
          pos+=SZ;next();
        };
        fr.readAsDataURL(blob.slice(pos,pos+SZ));
      })();
    });
  }
  function saveBlob(blob,name){
    toast('Download ho raha hai...');
    sendBlob(blob,name).then(function(id){B.finishSave(id);}).catch(function(e){toast('Download fail: '+e);});
  }
  window.__acSaveBlob=saveBlob;
  function hook(win){
    try{
      if(win.__acH){return;}
      win.__acH=true;
      var doc=win.document;
      function handleAnchor(a){
        try{
          if(!a||a.tagName!=='A'||!a.hasAttribute('download')){return false;}
          var h=a.href||'';
          if(h.indexOf('blob:')!==0&&h.indexOf('data:')!==0){return false;}
          var nm=a.getAttribute('download')||'';
          win.fetch(h).then(function(r){return r.blob();}).then(function(b){saveBlob(b,nm);}).catch(function(e){toast('Download fail: '+e);});
          return true;
        }catch(e){return false;}
      }
      var AP=win.HTMLAnchorElement.prototype,oc=AP.click;
      AP.click=function(){if(handleAnchor(this)){return;}return oc.apply(this,arguments);};
      var ET=win.EventTarget.prototype,od=ET.dispatchEvent;
      ET.dispatchEvent=function(ev){
        try{if(ev&&ev.type==='click'&&this instanceof win.HTMLAnchorElement&&handleAnchor(this)){return true;}}catch(e){}
        return od.apply(this,arguments);
      };
      doc.addEventListener('click',function(ev){
        var n=ev.target;
        while(n&&n.tagName!=='A'){n=n.parentNode;}
        if(n&&handleAnchor(n)){ev.preventDefault();ev.stopPropagation();}
      },true);
      win.print=function(){try{B.print();}catch(e){}};
      var nav=win.navigator;
      Object.defineProperty(nav,'canShare',{configurable:true,writable:true,value:function(d){
        return !!d&&((d.files&&d.files.length>0)||!!d.text||!!d.url||!!d.title);
      }});
      Object.defineProperty(nav,'share',{configurable:true,writable:true,value:function(d){
        d=d||{};
        var files=d.files||[],tasks=[];
        for(var i=0;i<files.length;i++){tasks.push(sendBlob(files[i],files[i].name||('file'+i)));}
        return Promise.all(tasks).then(function(ids){B.share(JSON.stringify(ids),d.title||'',d.text||'',d.url||'');});
      }});
    }catch(e){}
  }
  hook(window);
  function hookFrames(){
    var f=document.getElementsByTagName('iframe');
    for(var i=0;i<f.length;i++){
      try{if(f[i].contentWindow&&f[i].contentWindow.document){hook(f[i].contentWindow);}}catch(e){}
    }
  }
  document.addEventListener('load',function(ev){
    var t=ev.target;
    if(t&&t.tagName==='IFRAME'){try{hook(t.contentWindow);}catch(e){}}
  },true);
  function overrides(){
    window.apSaveBlob=function(blob,name){saveBlob(blob,name);};
    hookFrames();
  }
  overrides();
  document.addEventListener('DOMContentLoaded',overrides);
  window.addEventListener('load',overrides);
})();
"""
}
