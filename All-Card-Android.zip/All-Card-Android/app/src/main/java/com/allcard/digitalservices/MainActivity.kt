package com.allcard.digitalservices

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.webkit.CookieManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.snackbar.Snackbar
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var topProgress: LinearProgressIndicator
    private lateinit var overlay: View
    private lateinit var bridge: DownloadBridge

    private val ui = Handler(Looper.getMainLooper())
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var usingLocal = false
    private var overlayHidden = false
    private var backPressedOnce = false

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(AppConfig.ASSET_HOST)
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
        }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        webView = findViewById(R.id.webView)
        topProgress = findViewById(R.id.topProgress)
        overlay = findViewById(R.id.overlay)

        DownloadBridge.cleanTemp(this)
        bridge = DownloadBridge(
            this,
            onSaved = { uri, name, mime -> onFileSaved(uri, name, mime) },
            onPrint = { printPage() }
        )

        askLegacyStoragePermission()
        setupWebView()
        setupBackPress()
        startLoading()
    }

    // ---------------------------------------------------------------- loading

    private fun startLoading() {
        if (!AppConfig.USE_LIVE_URL) {
            loadLocal()
        } else if (isOnline()) {
            usingLocal = false
            webView.loadUrl(AppConfig.LIVE_URL)
        } else {
            showOfflineDialog()
        }
    }

    private fun loadLocal() {
        usingLocal = true
        webView.loadUrl(AppConfig.LOCAL_URL)
    }

    private fun fallbackToLocal() {
        if (usingLocal) return
        usingLocal = true
        Toast.makeText(this, "Live site nahi khuli, app ki built-in copy chal rahi hai", Toast.LENGTH_LONG).show()
        webView.post { webView.loadUrl(AppConfig.LOCAL_URL) }
    }

    private fun showOfflineDialog() {
        AlertDialog.Builder(this)
            .setTitle("Internet nahi hai")
            .setMessage("All Card chalane ke liye internet (WiFi / mobile data) chalu karein.")
            .setCancelable(false)
            .setPositiveButton("Dobara try karein") { _, _ -> startLoading() }
            .setNeutralButton("Offline kholein") { _, _ -> loadLocal() }
            .setNegativeButton("Band karein") { _, _ -> finish() }
            .show()
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun hideOverlay() {
        if (overlayHidden) return
        overlayHidden = true
        overlay.animate().alpha(0f).setDuration(300).withEndAction { overlay.visibility = View.GONE }.start()
    }

    // ---------------------------------------------------------------- webview

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            textZoom = 100
            javaScriptCanOpenWindowsAutomatically = true
            userAgentString = userAgentString + " AllCardApp/1.0"
        }

        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        cookies.setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(bridge, "AndroidBridge")

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            val origins = mutableSetOf("https://" + AppConfig.ASSET_HOST)
            if (AppConfig.liveHost.isNotEmpty()) origins.add("https://" + AppConfig.liveHost)
            WebViewCompat.addDocumentStartJavaScript(webView, WebHooks.SCRIPT, origins)
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            handleDownload(url, userAgent, contentDisposition, mimetype)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: return false
                if (scheme == "blob" || scheme == "data" || scheme == "about" || scheme == "javascript") return false
                if (!request.isForMainFrame) return false
                val host = uri.host ?: ""
                if ((scheme == "https" || scheme == "http") &&
                    (host == AppConfig.ASSET_HOST || host == AppConfig.liveHost)
                ) return false
                openExternal(uri)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    view.evaluateJavascript(WebHooks.SCRIPT, null)
                }
                hideOverlay()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) fallbackToLocal()
            }

            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse
            ) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) fallbackToLocal()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                topProgress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                topProgress.setProgressCompat(newProgress, true)
                if (newProgress >= 70) hideOverlay()
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    Toast.makeText(this@MainActivity, "File chooser nahi khul paya", Toast.LENGTH_SHORT).show()
                    false
                }
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult
            ): Boolean {
                val input = EditText(this@MainActivity)
                input.setText(defaultValue ?: "")
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setView(input)
                    .setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .show()
                return true
            }
        }
    }

    // ---------------------------------------------------------------- downloads

    private fun handleDownload(url: String, ua: String?, contentDisposition: String?, mime: String?) {
        val name = URLUtil.guessFileName(url, contentDisposition, mime)

        if (url.startsWith("blob:") || url.startsWith("data:")) {
            val js = "(function(){fetch(" + JSONObject.quote(url) + ")" +
                ".then(function(r){return r.blob();})" +
                ".then(function(b){if(window.__acSaveBlob){window.__acSaveBlob(b," + JSONObject.quote(name) + ");}});})();"
            webView.evaluateJavascript(js, null)
            return
        }

        if (url.startsWith("http")) {
            try {
                val req = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mime)
                    .addRequestHeader("User-Agent", ua ?: "")
                    .setTitle(name)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "All Card/$name")
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Download shuru: $name", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openExternal(Uri.parse(url))
            }
        }
    }

    private fun onFileSaved(uri: Uri, name: String, mime: String) {
        Snackbar.make(root, "\u2705 Saved: $name\nDownloads / All Card folder me", 8000)
            .setAction("KHOLEIN") { openSaved(uri, mime) }
            .show()
    }

    private fun openSaved(uri: Uri, mime: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Is file ko kholne wala app nahi mila", Toast.LENGTH_LONG).show()
        }
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            Toast.makeText(this, "Ise kholne wala app nahi mila", Toast.LENGTH_SHORT).show()
        }
    }

    private fun printPage() {
        try {
            val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
            pm.print("All Card", webView.createPrintDocumentAdapter("All Card"), PrintAttributes.Builder().build())
        } catch (e: Exception) {
            Toast.makeText(this, "Print nahi ho paya", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askLegacyStoragePermission() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    // ---------------------------------------------------------------- lifecycle

    private fun setupBackPress() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                    return
                }
                if (backPressedOnce) {
                    finish()
                    return
                }
                backPressedOnce = true
                Toast.makeText(this@MainActivity, "Bahar nikalne ke liye dobara Back dabayein", Toast.LENGTH_SHORT).show()
                ui.postDelayed({ backPressedOnce = false }, 2000)
            }
        })
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        root.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }
}
