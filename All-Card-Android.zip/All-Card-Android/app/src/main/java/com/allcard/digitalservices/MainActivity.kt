package com.allcard.digitalservices

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.progressindicator.LinearProgressIndicator
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var topProgress: LinearProgressIndicator
    private lateinit var overlay: View
    private lateinit var bridge: DownloadBridge

    private lateinit var dlBanner: View
    private lateinit var dlIcon: ImageView
    private lateinit var dlSpinner: ProgressBar
    private lateinit var dlTitle: TextView
    private lateinit var dlName: TextView
    private lateinit var dlSub: TextView
    private lateinit var dlOpen: TextView
    private lateinit var dlClose: View

    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("allcard", Context.MODE_PRIVATE) }
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var usingLocal = false
    private var clearHistoryPending = false
    private var overlayHidden = false
    private var backPressedOnce = false
    private var bannerUri: Uri? = null
    private var bannerMime: String = ""
    private val hideBannerRunnable = Runnable { hideBanner() }

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(AppConfig.ASSET_HOST)
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
        }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Screenshot aur screen recording band (har section me)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        webView = findViewById(R.id.webView)
        topProgress = findViewById(R.id.topProgress)
        overlay = findViewById(R.id.overlay)

        dlBanner = findViewById(R.id.dlBanner)
        dlIcon = findViewById(R.id.dlIcon)
        dlSpinner = findViewById(R.id.dlSpinner)
        dlTitle = findViewById(R.id.dlTitle)
        dlName = findViewById(R.id.dlName)
        dlSub = findViewById(R.id.dlSub)
        dlOpen = findViewById(R.id.dlOpen)
        dlClose = findViewById(R.id.dlClose)
        dlClose.setOnClickListener { hideBanner() }
        dlOpen.setOnClickListener { openBannerFile() }
        dlBanner.setOnClickListener { openBannerFile() }

        DownloadBridge.cleanTemp(this)
        bridge = DownloadBridge(
            this,
            onStart = { name -> onDownloadStarted(name) },
            onSaved = { uri, name, mime -> onFileSaved(uri, name, mime) },
            onError = { msg -> onDownloadError(msg) },
            onPrint = { printPage() }
        )

        askLegacyStoragePermission()
        setupWebView()
        setupBackPress()
        startLoading()
    }

    // ---------------------------------------------------------------- loading

    private fun startLoading() {
        if (!AppConfig.USE_LIVE_URL) {
            loadLocal()
            return
        }
        if (isOnline()) {
            webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
            usingLocal = false
            webView.loadUrl(AppConfig.LIVE_URL)
        } else {
            Toast.makeText(this, "Internet nahi hai - offline mode me khul raha hai", Toast.LENGTH_LONG).show()
            if (prefs.getBoolean("live_ok", false)) {
                // pehle khuli hui live site cache se
                webView.settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                usingLocal = false
                webView.loadUrl(AppConfig.LIVE_URL)
            } else {
                loadLocal()
            }
        }
    }

    private fun loadLocal() {
        usingLocal = true
        webView.loadUrl(AppConfig.LOCAL_URL)
    }

    private fun fallbackToLocal() {
        if (usingLocal) return
        usingLocal = true
        clearHistoryPending = true
        val msg = if (isOnline()) "Live site nahi khuli, app ki built-in copy chal rahi hai"
        else "Internet nahi hai, app ki built-in copy chal rahi hai"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        webView.post { webView.loadUrl(AppConfig.LOCAL_URL) }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun hideOverlay() {
        if (overlayHidden) return
        overlayHidden = true
        overlay.animate().alpha(0f).setDuration(300).withEndAction { overlay.visibility = View.GONE }.start()
    }

    // ---------------------------------------------------------------- webview

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            textZoom = 100
            javaScriptCanOpenWindowsAutomatically = true
            userAgentString = userAgentString + " AllCardApp/1.1"
        }

        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        cookies.setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(bridge, "AndroidBridge")

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            val origins = mutableSetOf("https://" + AppConfig.ASSET_HOST)
            if (AppConfig.liveHost.isNotEmpty()) origins.add("https://" + AppConfig.liveHost)
            WebViewCompat.addDocumentStartJavaScript(webView, WebHooks.SCRIPT, origins)
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            handleDownload(url, userAgent, contentDisposition, mimetype)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: return false
                if (scheme == "blob" || scheme == "data" || scheme == "about" || scheme == "javascript") return false
                if (!request.isForMainFrame) return false
                val host = uri.host ?: ""
                if ((scheme == "https" || scheme == "http") &&
                    (host == AppConfig.ASSET_HOST || host == AppConfig.liveHost)
                ) return false
                openExternal(uri)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    view.evaluateJavascript(WebHooks.SCRIPT, null)
                }
                // 404 wala page history se hata do, taaki Back dabane par wo na aaye
                if (clearHistoryPending && url != null && url.contains(AppConfig.ASSET_HOST)) {
                    clearHistoryPending = false
                    view.clearHistory()
                }
                if (!usingLocal && url != null && url.startsWith(AppConfig.LIVE_URL)) {
                    prefs.edit().putBoolean("live_ok", true).apply()
                }
                hideOverlay()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) fallbackToLocal()
            }

            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse
            ) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) fallbackToLocal()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                topProgress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                topProgress.setProgressCompat(newProgress, true)
                if (newProgress >= 70) hideOverlay()
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    Toast.makeText(this@MainActivity, "File chooser nahi khul paya", Toast.LENGTH_SHORT).show()
                    false
                }
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult
            ): Boolean {
                val input = EditText(this@MainActivity)
                input.setText(defaultValue ?: "")
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setView(input)
                    .setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .show()
                return true
            }
        }
    }

    // ---------------------------------------------------------------- downloads

    private fun handleDownload(url: String, ua: String?, contentDisposition: String?, mime: String?) {
        val name = URLUtil.guessFileName(url, contentDisposition, mime)

        if (url.startsWith("blob:") || url.startsWith("data:")) {
            val js = "(function(){fetch(" + JSONObject.quote(url) + ")" +
                ".then(function(r){return r.blob();})" +
                ".then(function(b){if(window.__acSaveBlob){window.__acSaveBlob(b," + JSONObject.quote(name) + ");}});})();"
            webView.evaluateJavascript(js, null)
            return
        }

        if (url.startsWith("http")) {
            try {
                val req = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mime)
                    .addRequestHeader("User-Agent", ua ?: "")
                    .setTitle(name)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "All Card/$name")
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading: $name", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openExternal(Uri.parse(url))
            }
        }
    }

    // ---- Chrome jaisa top banner ----

    private fun showBanner() {
        ui.removeCallbacks(hideBannerRunnable)
        dlBanner.animate().cancel()
        if (dlBanner.visibility != View.VISIBLE) {
            dlBanner.visibility = View.VISIBLE
            dlBanner.translationY = -400f
        }
        dlBanner.animate().translationY(0f).setDuration(220).start()
    }

    private fun hideBanner() {
        ui.removeCallbacks(hideBannerRunnable)
        dlBanner.animate().cancel()
        dlBanner.animate()
            .translationY(-(dlBanner.height.toFloat() + 80f))
            .setDuration(200)
            .withEndAction { dlBanner.visibility = View.GONE }
            .start()
    }

    private fun onDownloadStarted(name: String) {
        bannerUri = null
        dlSpinner.visibility = View.VISIBLE
        dlIcon.visibility = View.GONE
        dlTitle.text = "Downloading\u2026"
        dlName.text = if (name.isBlank()) "Preparing file" else name
        dlSub.text = "Please wait"
        dlOpen.visibility = View.GONE
        showBanner()
    }

    private fun onFileSaved(uri: Uri, name: String, mime: String) {
        bannerUri = uri
        bannerMime = mime
        dlSpinner.visibility = View.GONE
        dlIcon.setImageResource(R.drawable.ic_check_circle)
        dlIcon.visibility = View.VISIBLE
        dlTitle.text = "Download complete"
        dlName.text = name
        dlSub.text = "Saved in Downloads \u203A All Card"
        dlOpen.visibility = View.VISIBLE
        showBanner()
        ui.postDelayed(hideBannerRunnable, 8000)
    }

    private fun onDownloadError(msg: String) {
        bannerUri = null
        dlSpinner.visibility = View.GONE
        dlIcon.setImageResource(R.drawable.ic_error_circle)
        dlIcon.visibility = View.VISIBLE
        dlTitle.text = "Download failed"
        dlName.text = msg
        dlSub.text = "Please try again"
        dlOpen.visibility = View.GONE
        showBanner()
        ui.postDelayed(hideBannerRunnable, 6000)
    }

    private fun openBannerFile() {
        val u = bannerUri ?: return
        openSaved(u, bannerMime)
    }

    private fun openSaved(uri: Uri, mime: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No app found to open this file", Toast.LENGTH_LONG).show()
        }
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            Toast.makeText(this, "Ise kholne wala app nahi mila", Toast.LENGTH_SHORT).show()
        }
    }

    private fun printPage() {
        try {
            val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
            pm.print("All Card", webView.createPrintDocumentAdapter("All Card"), PrintAttributes.Builder().build())
        } catch (e: Exception) {
            Toast.makeText(this, "Print nahi ho paya", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askLegacyStoragePermission() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    // ---------------------------------------------------------------- lifecycle

    private fun setupBackPress() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                    return
                }
                if (backPressedOnce) {
                    finish()
                    return
                }
                backPressedOnce = true
                Toast.makeText(this@MainActivity, "Bahar nikalne ke liye dobara Back dabayein", Toast.LENGTH_SHORT).show()
                ui.postDelayed({ backPressedOnce = false }, 2000)
            }
        })
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        root.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }
}
