package com.allcard.digitalservices

import android.app.Application

class AllCardApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // App band ho tab bhi Push (FCM) ke liye har process start par Firebase chalu karo
        PushCfg.ensureInit(this)
    }
}
