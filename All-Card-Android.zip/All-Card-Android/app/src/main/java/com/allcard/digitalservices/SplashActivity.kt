package com.allcard.digitalservices

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

class SplashActivity : AppCompatActivity() {

    private var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logo = findViewById<View>(R.id.logo)
        val title = findViewById<View>(R.id.title)
        val subtitle = findViewById<View>(R.id.subtitle)
        val bottom = findViewById<View>(R.id.bottom)

        logo.alpha = 0f
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        title.alpha = 0f
        title.translationY = 40f
        subtitle.alpha = 0f
        subtitle.translationY = 40f
        bottom.alpha = 0f

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(700).setInterpolator(OvershootInterpolator()).start()
        title.animate().alpha(1f).translationY(0f).setStartDelay(350).setDuration(500).start()
        subtitle.animate().alpha(1f).translationY(0f).setStartDelay(550).setDuration(500).start()
        bottom.animate().alpha(1f).setStartDelay(700).setDuration(500).start()

        window.decorView.postDelayed({ openMain() }, 1900)
    }

    private fun openMain() {
        if (started || isFinishing || isDestroyed) return
        started = true
        startActivity(Intent(this, MainActivity::class.java))
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
