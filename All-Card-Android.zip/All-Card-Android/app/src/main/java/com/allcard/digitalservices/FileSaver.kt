package com.allcard.digitalservices

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileSaver {

    class Result(val uri: Uri, val name: String, val mime: String)

    fun guessMime(name: String, mime: String?): String {
        if (!mime.isNullOrBlank() && mime != "application/octet-stream") return mime
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    fun cleanName(raw: String?, mime: String?): String {
        var n = (raw ?: "").trim().replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_")
        if (n.length > 120) n = n.takeLast(120)
        if (n.isEmpty() || n == "." || n == "..") {
            n = "AllCard_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        }
        if (!n.contains('.')) {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime ?: "")
            if (!ext.isNullOrEmpty()) n += ".$ext"
        }
        return n
    }

    /** Downloads/All Card folder me save karta hai. Android 10+ par permission ki zarurat nahi. */
    @Throws(IOException::class)
    fun saveToDownloads(ctx: Context, src: File, rawName: String?, rawMime: String?): Result {
        val firstMime = guessMime(rawName ?: "", rawMime)
        val name = cleanName(rawName, firstMime)
        val mime = guessMime(name, rawMime)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/All Card")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("MediaStore insert nahi hua")
            val out = resolver.openOutputStream(uri) ?: throw IOException("File nahi khul payi")
            out.use { o -> src.inputStream().use { it.copyTo(o) } }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            return Result(uri, name, mime)
        }

        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "All Card")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Folder nahi ban paya (storage permission dein)")
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var f = File(dir, name)
        var i = 1
        while (f.exists()) {
            f = File(dir, "$base ($i)$ext")
            i++
        }
        src.copyTo(f, overwrite = false)
        MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf(mime), null)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        return Result(uri, f.name, mime)
    }
}
