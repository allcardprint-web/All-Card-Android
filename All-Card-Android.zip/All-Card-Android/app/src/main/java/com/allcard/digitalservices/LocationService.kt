package com.allcard.digitalservices

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Service ki ab ki halat (web page isse padhta hai). */
object LocState {
    @Volatile var running = false
    @Volatile var st = "off"
    @Volatile var lat: Double? = null
    @Volatile var lng: Double? = null
    @Volatile var acc: Int = -1
    @Volatile var fixAt = 0L
    @Volatile var sentAt = 0L
    @Volatile var err = ""
    @Volatile var bat = -1
    @Volatile var chg = false

    fun json(): String {
        val j = JSONObject()
        j.put("running", running)
        j.put("st", st)
        j.put("lat", lat ?: JSONObject.NULL)
        j.put("lng", lng ?: JSONObject.NULL)
        j.put("acc", if (acc >= 0) acc else JSONObject.NULL)
        j.put("fixAt", fixAt)
        j.put("sentAt", sentAt)
        j.put("err", err)
        j.put("bat", if (bat >= 0) bat else JSONObject.NULL)
        j.put("chg", chg)
        return j.toString()
    }
}

/**
 * Location Sharing ON hone par background me chalta hai (app band ho tab bhi).
 * Jab tak chal raha hai tab tak notification dikhta hai; band hote hi notification hat jata hai.
 * Location + battery seedhe Firestore (REST) me user ke apne login token se jaati hai.
 */
class LocationService : Service() {

    companion object {
        const val CHANNEL = "loc_share"
        const val NID = 4101
        private const val PREF = "locsvc"
        private const val MIN_MOVE_M = 25.0
        private const val MIN_GAP_MS = 20000L
        private const val HEARTBEAT_MS = 120000L
        private const val STALE_MS = 90000L

        fun start(ctx: Context, uid: String, apiKey: String, project: String, refresh: String) {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("uid", uid).putString("key", apiKey)
                .putString("proj", project).putString("rt", refresh)
                .putBoolean("on", true).apply()
            ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
            ctx.stopService(Intent(ctx, LocationService::class.java))
            LocState.running = false
            LocState.st = "off"
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var lm: LocationManager

    private var uid = ""
    private var apiKey = ""
    private var project = ""
    private var refreshToken = ""
    private var idToken = ""
    private var idExp = 0L

    private var updatesOn = false
    private var sentSt = ""
    private var lastSentLat: Double? = null
    private var lastSentLng: Double? = null
    @Volatile private var uploading = false
    private var shownText = ""

    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            onFix(l)
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }

        override fun onProviderEnabled(provider: String) {
        }

        override fun onProviderDisabled(provider: String) {
        }
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (e: Exception) {
                LocState.err = e.message ?: "error"
            }
            main.postDelayed(this, 5000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Location Sharing", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Location Sharing chalu hone par dikhta hai"
            ch.setShowBadge(false)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val sp = getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!sp.getBoolean("on", false)) {
            stopSelf()
            return START_NOT_STICKY
        }
        uid = sp.getString("uid", "") ?: ""
        apiKey = sp.getString("key", "") ?: ""
        project = sp.getString("proj", "") ?: ""
        refreshToken = sp.getString("rt", "") ?: ""
        idToken = ""
        idExp = 0L
        sentSt = ""

        shownText = "Aapki location Admin ko dikh rahi hai"
        val n = buildNotification(shownText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NID, n)
        }
        LocState.running = true
        LocState.st = "gps"
        LocState.err = ""
        stopUpdates()
        startUpdates()
        main.removeCallbacks(tickRunnable)
        main.post(tickRunnable)
        return START_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        stopUpdates()
        LocState.running = false
        LocState.st = "off"
        super.onDestroy()
    }

    // ------------------------------------------------------------ notification

    private fun buildNotification(text: String): Notification {
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            this, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif_pin)
            .setContentTitle("All Card \u2022 Location Sharing ON")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun refreshNotification(text: String) {
        if (text == shownText) return
        shownText = text
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NID, buildNotification(text))
        } catch (e: Exception) {
            // ignore
        }
    }

    // ------------------------------------------------------------ location

    private fun hasPerm(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startUpdates() {
        if (!hasPerm() || updatesOn) return
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000L, 0f, listener, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            // ignore
        }
        try {
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000L, 0f, listener, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            // ignore
        }
        updatesOn = true
    }

    private fun stopUpdates() {
        try {
            lm.removeUpdates(listener)
        } catch (e: Exception) {
            // ignore
        }
        updatesOn = false
    }

    private fun onFix(l: Location) {
        LocState.lat = l.latitude
        LocState.lng = l.longitude
        LocState.acc = Math.round(l.accuracy).toInt()
        LocState.fixAt = System.currentTimeMillis()
        LocState.st = "ok"
    }

    private fun readBattery() {
        try {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            LocState.bat = if (lvl >= 0 && sc > 0) (lvl * 100 / sc) else -1
            val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            LocState.chg = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun distM(aLat: Double, aLng: Double, bLat: Double, bLng: Double): Double {
        val r = 6371000.0
        val rad = Math.PI / 180.0
        val x = (bLat - aLat) * rad
        val y = (bLng - aLng) * rad * Math.cos((aLat + bLat) / 2 * rad)
        return Math.sqrt(x * x + y * y) * r
    }

    private fun tick() {
        readBattery()
        val now = System.currentTimeMillis()
        val perm = hasPerm()
        val enabled = try {
            LocationManagerCompat.isLocationEnabled(lm)
        } catch (e: Exception) {
            true
        }
        if (!perm) {
            LocState.st = "perm"
            stopUpdates()
        } else if (!enabled) {
            LocState.st = "gps"
            stopUpdates()
        } else {
            if (!updatesOn) startUpdates()
            if (LocState.st == "ok" && LocState.fixAt > 0 && now - LocState.fixAt > STALE_MS) LocState.st = "gps"
        }

        val st = LocState.st
        refreshNotification(
            when (st) {
                "ok" -> "Aapki location Admin ko dikh rahi hai"
                "perm" -> "Location permission band hai - chalu karein"
                else -> "GPS band hai ya location nahi mil rahi"
            }
        )

        if (!isOnline()) {
            LocState.err = "net"
            return
        }
        if (uploading) return
        val lat = LocState.lat
        val lng = LocState.lng
        val age = now - LocState.sentAt
        if (st == "ok" && lat != null && lng != null) {
            val sl = lastSentLat
            val sg = lastSentLng
            val moved = if (sl != null && sg != null) distM(sl, sg, lat, lng) else 1e9
            if (sentSt != "ok" || (moved >= MIN_MOVE_M && age >= MIN_GAP_MS) || age >= HEARTBEAT_MS) upload("ok")
        } else if (sentSt != st && (st == "gps" || st == "perm")) {
            upload(st)
        }
    }

    // ------------------------------------------------------------ upload (Firestore REST)

    private fun upload(st: String) {
        uploading = true
        val lat = LocState.lat
        val lng = LocState.lng
        val acc = LocState.acc
        val at = if (LocState.fixAt > 0) LocState.fixAt else System.currentTimeMillis()
        val bat = LocState.bat
        val chg = LocState.chg
        io.execute {
            try {
                val tok = token()
                val f = JSONObject()
                f.put("mobile", JSONObject().put("stringValue", uid))
                f.put("on", JSONObject().put("booleanValue", true))
                f.put("lat", if (lat != null) JSONObject().put("doubleValue", lat) else JSONObject().put("nullValue", "NULL_VALUE"))
                f.put("lng", if (lng != null) JSONObject().put("doubleValue", lng) else JSONObject().put("nullValue", "NULL_VALUE"))
                f.put("acc", if (acc >= 0) JSONObject().put("integerValue", acc.toString()) else JSONObject().put("nullValue", "NULL_VALUE"))
                f.put("at", JSONObject().put("integerValue", at.toString()))
                f.put("st", JSONObject().put("stringValue", st))
                f.put("bat", if (bat >= 0) JSONObject().put("integerValue", bat.toString()) else JSONObject().put("nullValue", "NULL_VALUE"))
                f.put("chg", JSONObject().put("booleanValue", chg))
                val name = "projects/$project/databases/(default)/documents/locations/$uid"
                val write = JSONObject().put("update", JSONObject().put("name", name).put("fields", f))
                val body = JSONObject().put("writes", org.json.JSONArray().put(write)).toString()

                val c = URL("https://firestore.googleapis.com/v1/projects/$project/databases/(default)/documents:commit")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 15000
                c.readTimeout = 15000
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $tok")
                c.outputStream.use { it.write(body.toByteArray()) }
                val code = c.responseCode
                if (code in 200..299) {
                    LocState.sentAt = System.currentTimeMillis()
                    LocState.err = ""
                    sentSt = st
                    lastSentLat = lat
                    lastSentLng = lng
                } else {
                    if (code == 401 || code == 403) idToken = ""
                    LocState.err = if (code == 403) "permission-denied" else "http$code"
                }
                c.disconnect()
            } catch (e: Exception) {
                LocState.err = e.message ?: "error"
            } finally {
                uploading = false
            }
        }
    }

    private fun token(): String {
        val now = System.currentTimeMillis()
        if (idToken.isNotEmpty() && now < idExp - 60000) return idToken
        val c = URL("https://securetoken.googleapis.com/v1/token?key=" + URLEncoder.encode(apiKey, "UTF-8"))
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        val data = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refreshToken, "UTF-8")
        c.outputStream.use { it.write(data.toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw Exception("token$code")
        val j = JSONObject(txt)
        idToken = j.getString("id_token")
        idExp = now + j.getString("expires_in").toLong() * 1000L
        val nr = j.optString("refresh_token")
        if (nr.isNotEmpty() && nr != refreshToken) {
            refreshToken = nr
            getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("rt", nr).apply()
        }
        return idToken
    }
}
