package com.allcard.digitalservices

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Service ki ab ki halat (web page isse padhta hai). */
object LocState {
    @Volatile var running = false
    @Volatile var mode = ""
    @Volatile var until = 0L
    @Volatile var st = "idle"
    @Volatile var lat: Double? = null
    @Volatile var lng: Double? = null
    @Volatile var acc: Int = -1
    @Volatile var fixAt = 0L
    @Volatile var sentAt = 0L
    @Volatile var err = ""
    @Volatile var bat = -1
    @Volatile var chg = false

    fun json(): String {
        val j = JSONObject()
        j.put("running", running)
        j.put("mode", mode)
        j.put("until", until)
        j.put("st", st)
        j.put("lat", lat ?: JSONObject.NULL)
        j.put("lng", lng ?: JSONObject.NULL)
        j.put("acc", if (acc >= 0) acc else JSONObject.NULL)
        j.put("fixAt", fixAt)
        j.put("sentAt", sentAt)
        j.put("err", err)
        j.put("bat", if (bat >= 0) bat else JSONObject.NULL)
        j.put("chg", chg)
        return j.toString()
    }
}

/**
 * Sirf Admin ke command par chalta hai:
 *  - "current": ek baar location bhejta hai, chhota notification dikhata hai, phir band.
 *  - "live"   : chuni hui der tak (until) lagataar location bhejta hai; notification sirf utni der dikhta hai.
 * Beech me kabhi band karna ho to bgStop() se turant band + notification gayab.
 */
class LocationService : Service() {

    companion object {
        const val CHANNEL = "loc_share"
        const val NID = 4101
        private const val PREF = "locsvc"
        private const val LIVE_MIN_MOVE_M = 10.0
        private const val LIVE_MIN_GAP_MS = 10000L
        private const val LIVE_HEARTBEAT_MS = 30000L
        private const val STALE_MS = 90000L
        private const val CURRENT_WAIT_MS = 45000L
        private const val MAX_LIVE_MS = 4 * 60 * 60 * 1000L

        fun startCmd(ctx: Context, mode: String, until: Long, uid: String, apiKey: String, project: String, refresh: String) {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("uid", uid).putString("key", apiKey)
                .putString("proj", project).putString("rt", refresh)
                .putBoolean("on", true).apply()
            val i = Intent(ctx, LocationService::class.java)
                .putExtra("mode", mode)
                .putExtra("until", until)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
            ctx.stopService(Intent(ctx, LocationService::class.java))
            LocState.running = false
            LocState.mode = ""
            LocState.until = 0L
            LocState.st = "idle"
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var lm: LocationManager

    private var uid = ""
    private var apiKey = ""
    private var project = ""
    private var refreshToken = ""
    private var idToken = ""
    private var idExp = 0L

    private var mode = "live"
    private var endAt = 0L
    private var updatesOn = false
    private var sentSt = ""
    private var lastSentLat: Double? = null
    private var lastSentLng: Double? = null
    @Volatile private var uploading = false
    @Volatile private var uploadedOnce = false
    private var finishing = false
    private var shownText = ""

    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            onFix(l)
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }

        override fun onProviderEnabled(provider: String) {
        }

        override fun onProviderDisabled(provider: String) {
        }
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (e: Exception) {
                LocState.err = e.message ?: "error"
            }
            if (!finishing) main.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Location Sharing", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Admin ke Live / Current request ke dauran dikhta hai"
            ch.setShowBadge(false)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val sp = getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (intent == null || !sp.getBoolean("on", false)) {
            stopSelf()
            return START_NOT_STICKY
        }
        uid = sp.getString("uid", "") ?: ""
        apiKey = sp.getString("key", "") ?: ""
        project = sp.getString("proj", "") ?: ""
        refreshToken = sp.getString("rt", "") ?: ""
        idToken = ""
        idExp = 0L
        sentSt = ""
        uploadedOnce = false
        finishing = false

        val now = System.currentTimeMillis()
        mode = intent.getStringExtra("mode") ?: "live"
        val until = intent.getLongExtra("until", 0L)
        endAt = if (mode == "live") {
            Math.min(if (until > now) until else now + 60000L, now + MAX_LIVE_MS)
        } else {
            now + CURRENT_WAIT_MS
        }
        LocState.mode = mode
        LocState.until = if (mode == "live") endAt else 0L

        shownText = notifText(now)
        val n = buildNotification(shownText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NID, n)
        }
        LocState.running = true
        LocState.st = "gps"
        LocState.err = ""
        stopUpdates()
        startUpdates()
        main.removeCallbacks(tickRunnable)
        main.post(tickRunnable)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        stopUpdates()
        LocState.running = false
        LocState.mode = ""
        LocState.until = 0L
        super.onDestroy()
    }

    // ------------------------------------------------------------ notification

    private fun notifText(now: Long): String {
        if (mode == "current") return "Aapki current location Admin ko bheji ja rahi hai"
        val mins = Math.max(1L, (endAt - now + 59999L) / 60000L)
        return "Admin aapki live location dekh rahe hain \u2022 $mins min baaki"
    }

    private fun buildNotification(text: String): Notification {
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            this, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif_pin)
            .setContentTitle(if (mode == "current") "All Card \u2022 Current Location" else "All Card \u2022 Live Location")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun refreshNotification(text: String) {
        if (text == shownText) return
        shownText = text
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NID, buildNotification(text))
        } catch (e: Exception) {
            // ignore
        }
    }

    // ------------------------------------------------------------ location

    private fun hasPerm(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startUpdates() {
        if (!hasPerm() || updatesOn) return
        val gap = if (mode == "live") 5000L else 1000L
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, gap, 0f, listener, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            // ignore
        }
        try {
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, gap, 0f, listener, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            // ignore
        }
        updatesOn = true
    }

    private fun stopUpdates() {
        try {
            lm.removeUpdates(listener)
        } catch (e: Exception) {
            // ignore
        }
        updatesOn = false
    }

    private fun onFix(l: Location) {
        LocState.lat = l.latitude
        LocState.lng = l.longitude
        LocState.acc = Math.round(l.accuracy).toInt()
        LocState.fixAt = System.currentTimeMillis()
        LocState.st = "ok"
    }

    private fun readBattery() {
        try {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            LocState.bat = if (lvl >= 0 && sc > 0) (lvl * 100 / sc) else -1
            val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            LocState.chg = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun distM(aLat: Double, aLng: Double, bLat: Double, bLng: Double): Double {
        val r = 6371000.0
        val rad = Math.PI / 180.0
        val x = (bLat - aLat) * rad
        val y = (bLng - aLng) * rad * Math.cos((aLat + bLat) / 2 * rad)
        return Math.sqrt(x * x + y * y) * r
    }

    private fun tick() {
        if (finishing) return
        val now = System.currentTimeMillis()
        readBattery()
        if (now >= endAt) {
            finishSession()
            return
        }
        val perm = hasPerm()
        val enabled = try {
            LocationManagerCompat.isLocationEnabled(lm)
        } catch (e: Exception) {
            true
        }
        if (!perm) {
            LocState.st = "perm"
            stopUpdates()
        } else if (!enabled) {
            LocState.st = "gps"
            stopUpdates()
        } else {
            if (!updatesOn) startUpdates()
            if (LocState.st == "ok" && LocState.fixAt > 0 && now - LocState.fixAt > STALE_MS) LocState.st = "gps"
        }
        refreshNotification(notifText(now))

        if (!isOnline()) {
            LocState.err = "net"
            return
        }
        if (uploading) return
        val st = LocState.st
        val lat = LocState.lat
        val lng = LocState.lng
        if (st == "ok" && lat != null && lng != null) {
            if (mode == "current") {
                if (!uploadedOnce) upload("ok", true)
            } else {
                val age = now - LocState.sentAt
                val sl = lastSentLat
                val sg = lastSentLng
                val moved = if (sl != null && sg != null) distM(sl, sg, lat, lng) else 1e9
                if (sentSt != "ok" || (moved >= LIVE_MIN_MOVE_M && age >= LIVE_MIN_GAP_MS) || age >= LIVE_HEARTBEAT_MS) {
                    upload("ok", false)
                }
            }
        } else if (sentSt != st && (st == "gps" || st == "perm")) {
            upload(st, false)
        }
    }

    /** Session poori: live ka samay khatam / current mil gayi / koi problem. */
    private fun finishSession() {
        if (finishing) return
        finishing = true
        main.removeCallbacks(tickRunnable)
        stopUpdates()
        val finalSt = if (LocState.lat != null) "idle" else if (LocState.st == "perm" || LocState.st == "gps") LocState.st else "idle"
        if (isOnline() && mode == "live") {
            io.execute {
                try {
                    doUpload(finalSt, false, true)
                } catch (e: Exception) {
                    LocState.err = e.message ?: "error"
                }
                main.post { endNow() }
            }
        } else {
            endNow()
        }
    }

    private fun endNow() {
        try {
            stopForeground(true)
        } catch (e: Exception) {
            // ignore
        }
        getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        LocState.running = false
        LocState.mode = ""
        LocState.until = 0L
        LocState.st = "idle"
        stopSelf()
    }

    // ------------------------------------------------------------ upload (Firestore REST)

    private fun upload(st: String, endAfter: Boolean) {
        uploading = true
        io.execute {
            try {
                doUpload(st, false, false)
                if (endAfter) {
                    uploadedOnce = true
                    main.postDelayed({ finishSession() }, 1500)
                }
            } catch (e: Exception) {
                LocState.err = e.message ?: "error"
            } finally {
                uploading = false
            }
        }
    }

    private fun doUpload(st: String, unused: Boolean, ending: Boolean) {
        val lat = LocState.lat
        val lng = LocState.lng
        val acc = LocState.acc
        val at = if (LocState.fixAt > 0) LocState.fixAt else System.currentTimeMillis()
        val bat = LocState.bat
        val chg = LocState.chg
        val lv = if (mode == "live" && !ending) endAt else 0L
        val tok = token()
        val f = JSONObject()
        f.put("mobile", JSONObject().put("stringValue", uid))
        f.put("on", JSONObject().put("booleanValue", true))
        f.put("lat", if (lat != null) JSONObject().put("doubleValue", lat) else JSONObject().put("nullValue", "NULL_VALUE"))
        f.put("lng", if (lng != null) JSONObject().put("doubleValue", lng) else JSONObject().put("nullValue", "NULL_VALUE"))
        f.put("acc", if (acc >= 0) JSONObject().put("integerValue", acc.toString()) else JSONObject().put("nullValue", "NULL_VALUE"))
        f.put("at", JSONObject().put("integerValue", at.toString()))
        f.put("st", JSONObject().put("stringValue", st))
        f.put("bat", if (bat >= 0) JSONObject().put("integerValue", bat.toString()) else JSONObject().put("nullValue", "NULL_VALUE"))
        f.put("chg", JSONObject().put("booleanValue", chg))
        f.put("lv", if (lv > 0) JSONObject().put("integerValue", lv.toString()) else JSONObject().put("nullValue", "NULL_VALUE"))
        val name = "projects/$project/databases/(default)/documents/locations/$uid"
        val write = JSONObject().put("update", JSONObject().put("name", name).put("fields", f))
        val body = JSONObject().put("writes", JSONArray().put(write)).toString()

        val c = URL("https://firestore.googleapis.com/v1/projects/$project/databases/(default)/documents:commit")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $tok")
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        if (code in 200..299) {
            LocState.sentAt = System.currentTimeMillis()
            LocState.err = ""
            sentSt = st
            lastSentLat = lat
            lastSentLng = lng
        } else {
            if (code == 401 || code == 403) idToken = ""
            LocState.err = if (code == 403) "permission-denied" else "http$code"
        }
        c.disconnect()
    }

    private fun token(): String {
        val now = System.currentTimeMillis()
        if (idToken.isNotEmpty() && now < idExp - 60000) return idToken
        val c = URL("https://securetoken.googleapis.com/v1/token?key=" + URLEncoder.encode(apiKey, "UTF-8"))
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        val data = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refreshToken, "UTF-8")
        c.outputStream.use { it.write(data.toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw Exception("token$code")
        val j = JSONObject(txt)
        idToken = j.getString("id_token")
        idExp = now + j.getString("expires_in").toLong() * 1000L
        val nr = j.optString("refresh_token")
        if (nr.isNotEmpty() && nr != refreshToken) {
            refreshToken = nr
            getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("rt", nr).apply()
            Creds.updateRt(this, nr)
        }
        return idToken
    }
}
